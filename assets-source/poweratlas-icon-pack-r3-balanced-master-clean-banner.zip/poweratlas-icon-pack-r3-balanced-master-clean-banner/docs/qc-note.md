# PowerAtlas R3 Balanced Master QC

This pack replaces the previous contact-sheet-derived crop with a clean 1024×1024 raster composite: the rounded dark tile was rebuilt from scratch, then the selected R2 #5 mark was recentered, scaled down slightly, and composited with safe margins.

## Centering and margins

- Tile bounds: `(84, 80, 940, 936)` on a 1024×1024 canvas.
- Tile margins: left `84px`, top `80px`, right `84px`, bottom `88px`.
- Estimated bright-signal bbox: `(121, 131, 861, 811)`.
- The apex, centerline, and command node are aligned at x=512; the bright-signal bbox is left-biased because the blue limb is intentionally brighter than the graphite limb.
- The mark is intentionally more spacious than the previous pack, especially on the right side.
- The source no longer has the old right-edge rounded-panel crop.

## Asset coverage

- App PNG: 1024, 512, 256, 128, 64, 48, 32, 24, 20, 16 px.
- Windows ICO: multi-size app icon.
- macOS: `.iconset` plus `.icns` (created with Pillow ICNS writer).
- Tray: PNG sizes 64, 48, 32, 24, 20, 16 px plus tray ICO.
- Web: favicon PNG/ICO, PWA icons, contained logo mark, and dark top banner.
- Preview: light/dark UI, favicon/tray, small-size, and banner checks.

## Caveat

This is a polished raster correction based on the selected generated direction, not a hand-redrawn vector identity system. It is suitable as a stronger working master; a final commercial-grade pass would still benefit from manually redrawing the A/atlas geometry for perfectly controlled symmetry and line weights.


## Clean banner update

- The web UI top banner now contains only the core contained icon mark and the `PowerAtlas` name.
- Removed all motto/tagline/descriptor text from the banner.
- The rest of the R3 balanced icon asset coverage is preserved.
